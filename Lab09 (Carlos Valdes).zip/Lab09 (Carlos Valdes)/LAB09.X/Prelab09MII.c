/* 
 * Archivo: Prelab09.c
 * Dispositivo: PIC16F887
 * Autor: Carlos Julio Vald�s Oajaca
 * Compilador: XC8, MPLABX v6.05
 
 * Programa: Modificar contador y despertar del PIC
 * Hardware: 

 * Creado: 13 de abril, 2023
 * �ltima modificaci�n: 13 de abril, 2023
 */

// PIC16F887 Configuration Bit Settings
// 'C' source line config statements
// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)
// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <pic16f887.h>
#include <xc.h>
#include <stdint.h>

///////////////////////////////////DEFINIR CONSTANTES///////////////////////////////////////////////////////////////////////////////////
#define _XTAL_FREQ 4000000 //8MHz
////////////////////////////////////VARIABLES GLOBALES/////////////////////////////////////////////////////////////////////////////////
uint8_t POT = 0;
/////////////////////////////////////PROTOTIPOS DE FUNCIONES///////////////////////////////////////////////////////////////////////////
void setup(void);
uint8_t read_EEPROM(uint8_t address);
void write_EEPROM(uint8_t address, uint8_t data);
/////////////////////////////////////INTERRUPCIONES//////////////////////////////////////////////////////////////////////////////////
void __interrupt() isr(void)
{
    if(PIR1bits.ADIF == 1)
    {
       POT = ADRESH;      //Enviar contenido de la conversion a variable POT
       PORTA = POT;       //Mostrar el valor en PORTA
       PIR1bits.ADIF = 0; //Limpiar bandera del ADC
    }
    
    if(INTCONbits.RBIF)
    {
        if(!PORTBbits.RB2)  //RB2 delay para despertar posteriormente al PIC
        {
            __delay_ms(100);
        }
     INTCONbits.RBIF = 0;  //limpiar bandera   
    }
        
}
///////////////////////////////////////CODIGO PRINCIPAL/////////////////////////////////////////////////////////////////////

void main(void) {
    setup(); //llamar a la configuracion
    ADCON0bits.GO = 1; //Primera conversion del ADC
    
 ////LOOP PRINCIPAL/////   
    while(1) //Loop infinito
    {
        if(ADCON0bits.GO == 0){   //Realizar la verificacion para las conversiones
            __delay_us(50);
            ADCON0bits.GO = 1;
        }
        if(!PORTBbits.RB1)  //Si se apacha RB1 poner PIC en sleep
        {
          SLEEP();  
        }
    }
    
}
//////////////////////////////////////SETUP/////////////////////////////////////////////////////////////////////
void setup(void)
{
    //configuracion de pines y puertos    
    ANSEL= 0b00100000;  //AN5 para el POT
    ANSELH= 0; //configura los pines de portB como digital
    
    TRISE = 0b0001;      //RE0 como entrada
    TRISB = 0b00000111;  //configurar botones en portB
    TRISA = 0b00000000;  //Valor POT
    TRISD = 0;           //Valor EEPROM
    //TRISC = 0;
    
    //Inicializar los puertos en 0
    PORTA = 0;
    PORTB = 0;
    PORTD = 0;
    PORTE = 0;
    //PORTC = 0;
    
    //configuracion de pull-ups
    OPTION_REGbits.nRBPU = 0; //Habilitamos pull-up en B
    //WPUBbits.WPUB0 = 1;       //Habilitamos pull-up en los pines deseados
    WPUBbits.WPUB1 = 1;
    WPUBbits.WPUB2 = 1;
    
    //configuracion oscilador
    OSCCONbits.IRCF = 0b0110; //4MHz
    OSCCONbits.SCS = 1;       //Utilizar el reloj interno
    
    //configuracion del ADC
    ADCON1bits.ADFM = 0; //Justificado a la izquierda
    ADCON1bits.VCFG0 = 0; //Referencia en VDD
    ADCON1bits.VCFG1 = 0; //Referencia en VSS 
    
    ADCON0bits.ADCS = 0b01; //ADCS <1:0> -> 01 Fosc/8
    ADCON0bits.CHS = 0b0101;     //CHS <3:0> AN5
    ADCON0bits.ADON = 1;    //Encender ADC
    __delay_us(50);
    
    //configuracion de interrupciones
    INTCONbits.PEIE = 1; //Habilitar interrupciones perifericas
    INTCONbits.GIE = 1; // Habilita interrupciones generales
    
    INTCONbits.RBIE = 1; //Habilitar interrupcion del PORTB
   // IOCBbits.IOCB0 = 1;  //Habilitar interrupt-on change
    IOCBbits.IOCB2 = 1;
    INTCONbits.RBIF = 0; //Inicializar bandera de portB en 0
    
    PIE1bits.ADIE = 1;   //Habilitar interrupciones analogas
    PIR1bits.ADIF = 0;   //Inicializar bandera en 0

}
//////////////////////////////////////FUNCIONES/////////////////////////////////////////////////////////////////////
/*uint8_t read_EEPROM(uint8_t address)
{
    EEADR = address;
    EECON1bits.EEPGD = 0; //Leer de la EEPROM
    EECON1bits.RD = 1;    //Obtener dato de la EEPROM
    return EEDAT;        //Regresar el dato
}        
///////////////////////////////////////////////////////////////////////////////////
void write_EEPROM(uint8_t address, uint8_t data)
{
    EEADR = address;
    EEDAT = data;
    EECON1bits.EEPGD = 0; //Escritura de la EEPROM
    EECON1bits.WREN = 1;  //Habilitar escritura de la EEPROM
    
    INTCONbits.GIE = 0;   //Deshabilitar interrupciones globales
    INTCONbits.PEIE = 0;  //Deshabilitar interrupciones perifericas
    EECON2 = 0x55;
    EECON2 = 0xAA;
    
    EECON1bits.WR = 1;    //Iniciar escritura
    
    EECON1bits.WREN = 0;  //Deshabilitar escritura de la EEPROM
    INTCONbits.RBIF = 1;  //Habilitar interrupciones
    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
}*/
